<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>{{ config('app.name')}}</title>
	 <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
	
	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css')}}">

	<style>
		body{
			font-family: Nunito;
		}
	</style>
</head>
<body>
	@yield('content')
</body>

<!-- JavaScript Bundle with Popper -->
<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
</html>