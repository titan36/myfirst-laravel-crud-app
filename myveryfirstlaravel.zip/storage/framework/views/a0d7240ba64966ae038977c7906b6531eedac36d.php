<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-12 text-center pt-5">
            <h1 class="display-one mt-5"><?php echo e(config('app.name')); ?></h1>
                <p>This awesome blog has many articles, click the button below to see them</p>
                <br>
                <a href="/blog" class="btn btn-outline-primary">Show Blog</a>
        </div>
    </div>
</content>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tito\Downloads\laravel1\myveryfirstlaravel\resources\views/welcome.blade.php ENDPATH**/ ?>