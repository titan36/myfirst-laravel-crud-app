<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo e(config('app.name')); ?></title>
	 <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

	<style>
		body{
			font-family: Nunito;
		}
	</style>
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>

<!-- JavaScript Bundle with Popper -->
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
</html><?php /**PATH C:\Users\tito\Downloads\laravel1\myveryfirstlaravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>